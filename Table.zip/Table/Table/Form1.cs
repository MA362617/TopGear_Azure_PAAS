﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using System.Configuration;

namespace Table
{

  
    public partial class Form1 : Form
    {
        string storageAccountName = ConfigurationManager.AppSettings["StorageAccountName"];
        string accountAccountKey = ConfigurationManager.AppSettings["AccessKey"];
        StorageCredentials storageCredentials;
        CloudStorageAccount account;
        CloudTableClient cloudTableClient;
        CloudTable azureTable;
        


        public Form1()
        {
            InitializeComponent();
            storageCredentials = new StorageCredentials(storageAccountName, accountAccountKey);
            account = new CloudStorageAccount(storageCredentials, useHttps: true);
            cloudTableClient = account.CreateCloudTableClient();
            txtTableName.Text = "test";
            string tableName = txtTableName.Text;
            azureTable = cloudTableClient.GetTableReference(tableName);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtProductId.Text) || string.IsNullOrEmpty(txtProductName.Text) || string.IsNullOrEmpty(txtProductPrice.Text) || string.IsNullOrEmpty(txtTableName.Text))
            {

                MessageBox.Show("Enter the data");
                Application.Exit();

            }
            else
            {
                var prodEntity = new Product
                {
                    ProdID = int.Parse(txtProductId.Text),
                    ProdName = txtProductName.Text,
                    Category = txtProductPrice.Text,
                };
                prodEntity.RowKey = prodEntity.ProdID + " " + ProductName;
                prodEntity.PartitionKey = prodEntity.Category;

                TableOperation tableOperation = TableOperation.Insert(prodEntity);
                azureTable.Execute(tableOperation);
                MessageBox.Show("Data Inserted");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string tableName = txtTableName.Text;
            azureTable = cloudTableClient.GetTableReference(tableName);
            azureTable.CreateIfNotExists();
            MessageBox.Show("Azure table is created");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string tableName = txtTableName.Text;
            azureTable = cloudTableClient.GetTableReference(tableName);
            TableQuery<Product> query = new TableQuery<Product>();
            var prodEntites = azureTable.ExecuteQuery(query);
            foreach (var entity in prodEntites)
            {
                lstBox.Items.Add(entity.ProdID + " " + entity.ProdName + " " + entity.Category);
            }
            MessageBox.Show("Data's are Listed");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
