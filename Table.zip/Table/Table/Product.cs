﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Table
{
    public class Product : TableEntity
    {
        public int ProdID { get; set; }
        public string ProdName { get; set; }
        public int Price { get; set; }
        public string Category { get; set; }
    }

}
