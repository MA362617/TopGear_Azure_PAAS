﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Queue;
using System.Configuration;

namespace TopGearQueue
{
    public partial class Form1 : Form
    {
        string storageAccountName = ConfigurationManager.AppSettings["StorageAccountName"];
        string accountAccountKey = ConfigurationManager.AppSettings["AccessKey"];

        StorageCredentials storageCredentials;
        CloudStorageAccount account;
        CloudQueueClient cloudQueueClient;
        CloudQueue azureQueue;
        public Form1()
        {
            InitializeComponent();
            storageCredentials = new StorageCredentials(storageAccountName, accountAccountKey);
            account = new CloudStorageAccount(storageCredentials, useHttps: true);
            cloudQueueClient = account.CreateCloudQueueClient();
        }


        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string queueName = textBox1.Text;
            azureQueue = cloudQueueClient.GetQueueReference(queueName);
            azureQueue.CreateIfNotExists();
            MessageBox.Show("Azure Queue is created");

            
            //var perm = new BlobContainerPermissions();
            //perm.PublicAccess = BlobContainerPublicAccessType.Container;
            //cloudBlobContainer.SetPermissions(perm);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text) | String.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("enter the data");
                Application.Exit();
            }
            else
            { 
            string message = textBox2.Text;
            CloudQueueMessage cloudQueueMessage = new CloudQueueMessage(message);
            azureQueue.AddMessage(cloudQueueMessage);
            textBox2.Text = "";
            MessageBox.Show("Added");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int count = 0;
            var messages = azureQueue.GetMessages(10);
            foreach (var message in messages)
            {
                listBox1.Items.Add(message.AsString);
                count++;
            }
            if(count>0)
            {
                MessageBox.Show("Data's are Listed");
            }
            
        }
    }
}
